def handler(event, context):
    return "<h3>Currently down for maintenance</h3>"
